import matplotlib.pyplot as plt
import math
import cv2
import numpy as np

def plot_histogram(original_image):
    f, axes = plt.subplots(2,1)
    axes[0].imshow(original_image, 'gray', vmin=0, vmax=255)
    histogram = axes[1].hist(original_image.flatten(), range=(0,255), bins=255)
    plt.tight_layout()
    plt.show()

image = cv2.imread('fig1.jpg')

plot_histogram(image)

image[image>=60] = 255
image[image<60] = 0

plt.imshow(image)
plt.show()

