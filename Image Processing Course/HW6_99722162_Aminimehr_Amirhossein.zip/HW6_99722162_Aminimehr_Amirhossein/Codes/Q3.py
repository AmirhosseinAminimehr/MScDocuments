import cv2
import numpy as np
from math import sqrt


def calc_distance(p1, p2):
    (x1, y1) = p1
    (x2, y2) = p2
    return round(sqrt((x1-x2)**2 + (y1-y2)**2))

def draw_blue_circle(event, x, y, flags, param):
    if event == cv2.EVENT_LBUTTONDBLCLK:
        seedX = y
        seedY = x
        seed = [seedX,seedY]
        imageToSeed = np.add(image,-1*image[seedX,seedY])
        stack = [seed]
        seen = [seed]

        while True:
            popedOne = stack[-1]
            stack.pop(-1)
            for i in range (-1,2):
                for j in range (-1,2):
                    if abs(image[popedOne[0],popedOne[1],0] - image[popedOne[0]+i,popedOne[1]+j,0]) == 0 and abs(image[popedOne[0],popedOne[1],1] - image[popedOne[0]+i,popedOne[1]+j,1])==0 and abs(image[popedOne[0],popedOne[1],2] - image[popedOne[0]+i,popedOne[1]+j,2]) == 0:
                        if [popedOne[0]+i,popedOne[1]+j] not in seen:
                            seen.append([popedOne[0]+i,popedOne[1]+j])
                            stack.append([popedOne[0]+i,popedOne[1]+j])
            if(len(stack) == 0):
                break

        for i in range(len(seen)):
            cv2.line(image, (seen[i][1],seen[i][0]), (seen[i][1],seen[i][0]), color=(255, 0, 0))


image = cv2.imread('Balls.jpg')
image[image >= 100] = 255
image[image < 100] = 0

cv2.namedWindow("Double click on spots! (q to exit)")

cv2.setMouseCallback("Double click on spots! (q to exit)", draw_blue_circle)

while True:
    cv2.imshow("Double click on spots! (q to exit)",image)
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break


cv2.destroyAllWindows()