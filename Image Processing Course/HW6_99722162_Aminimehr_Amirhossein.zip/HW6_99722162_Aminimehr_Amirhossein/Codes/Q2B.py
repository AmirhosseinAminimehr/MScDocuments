import matplotlib.pyplot as plt
import cv2
import numpy as np

def plot_histogram(original_image):
    f, axes = plt.subplots(2,1)
    axes[0].imshow(original_image, 'gray', vmin=0, vmax=255)
    histogram = axes[1].hist(original_image.flatten(), range=(0,255), bins=255)
    plt.tight_layout()
    plt.show()

def compute_histogram(image):
    histogram = np.zeros((256), np.int)
    for i in image:
        for j in i:
            histogram[j] += 1
    return histogram

def variance(data):
    # Number of observations
    n = len(data)
    # Mean of the data
    mean = sum(data) / n
    # Square deviations
    deviations = [(x - mean) ** 2 for x in data]
    # Variance
    variance = sum(deviations) / n
    return variance

def Otsu(image):
    imageHistogram = compute_histogram(image)
    minVW = 10000000000000000000000000
    minI = 0
    for i in range(1, len(imageHistogram)):
        hist1 = imageHistogram[:i]
        hist2 = imageHistogram[i:]
        w1 = np.sum(hist1) / np.sum(imageHistogram)
        w2 = np.sum(hist2) / np.sum(imageHistogram)
        v1 = variance(hist1)
        v2 = variance(hist2)
        vw = (w1 * (v1 ** 2)) + (w2 * (v2 ** 2))
        if vw < minVW:
            minVW = vw
            minI = i
    return minI

image = cv2.imread('fig1.jpg',cv2.IMREAD_GRAYSCALE)

plot_histogram(image)

threshold,image = cv2.threshold(image,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)
# minI = Otsu(image)
#
print("The threshold is " + str(threshold))
#
# image[image>=minI] = 255
# image[image<minI] = 0

plt.imshow(image)
plt.show()
