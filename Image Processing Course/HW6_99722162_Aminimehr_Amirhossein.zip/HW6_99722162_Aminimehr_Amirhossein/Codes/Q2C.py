import matplotlib.pyplot as plt
import cv2
import numpy as np

def compute_histogram(image):
    histogram = np.zeros((256), np.int)
    for i in image:
        for j in i:
            histogram[int(j)] += 1
    return histogram

def variance(data):
    # Number of observations
    n = len(data)
    # Mean of the data
    mean = sum(data) / n
    # Square deviations
    deviations = [(x - mean) ** 2 for x in data]
    # Variance
    variance = sum(deviations) / n
    return variance

def Otsu(image):
    imageHistogram = compute_histogram(image)
    minVW = 10000000000000000000000000
    minI = 0
    for i in range(1, len(imageHistogram)):
        hist1 = imageHistogram[:i]
        hist2 = imageHistogram[i:]
        w1 = np.sum(hist1) / np.sum(imageHistogram)
        w2 = np.sum(hist2) / np.sum(imageHistogram)
        v1 = variance(hist1)
        v2 = variance(hist2)
        vw = (w1 * (v1 ** 2)) + (w2 * (v2 ** 2))
        if vw < minVW:
            minVW = vw
            minI = i
    return minI

def convolve2d(image, kernel):
    # You do not need to modify these, but feel free to implement your own
    kernel       = np.flipud(np.fliplr(kernel))  # Flip the kernel, if it's symmetric it does not matter
    kernel_width = kernel.shape[0]
    kernel_height= kernel.shape[1]
    padding      = (kernel_width - 1)
    offset       = padding // 2
    output       = np.zeros_like(image)
    # Add zero padding to the input image
    image_padded = np.zeros((image.shape[0] + padding, image.shape[1] + padding))
    image_padded[offset:-offset, offset:-offset] = image

    # implement the convolution inside the inner for loop
    for y in range(image.shape[0]):
        for x in range(image.shape[1]):
            sum = 0
            for i in range(0,len(kernel)):
                for j in range(0,len(kernel)):
                    sum = sum + kernel[i][j] * image_padded[y-i][x-j]
            output[y][x] = sum
            # Convolution - Your code here
            continue
    return output


def adaptive(image,block,C):
    paddingX = image.shape[0]%block[0]
    paddingY = image.shape[1]%block[1]

    paddImage = np.zeros((image.shape[0]+paddingX,image.shape[1]+paddingY))

    for i in range(paddImage.shape[0]):
        for j in range(paddImage.shape[1]):
            if i < image.shape[0] and j < image.shape[1]:
                paddImage[i][j] = int(image[i][j][0])

            else:
                paddImage[i][j] = int(0)

    paddImage = np.array(paddImage)
    fullImage = []
    for i in range (int(paddImage.shape[0]/block[0])):
        imageRow = []
        for j in range (int(paddImage.shape[1]/block[1])):
            imageCut = paddImage[i*block[0]:(i+1)*block[0],j*block[1]:(j+1)*block[1]]
            minI = Otsu(imageCut) - C
            imageCut[imageCut >= minI] = 255
            imageCut[imageCut < minI] = 0
            imageRow.append(imageCut)
        if(len(fullImage) == 0):
            fullImage = cv2.hconcat(imageRow)
        else:
            fullImage = cv2.vconcat([fullImage , cv2.hconcat(imageRow)])

    return fullImage


image = cv2.imread('fig1.jpg',cv2.IMREAD_GRAYSCALE)

image = cv2.medianBlur(image,5)

adp = cv2.adaptiveThreshold(image,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,cv2.THRESH_BINARY,5,0)

plt.imshow(adp)
plt.show()
