import cv2
import matplotlib.pyplot as plt
import numpy as np

img = cv2.imread("shapes.jpg")

plt.imshow(img, "gray"), plt.title("Original Image")

gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

gray = cv2.GaussianBlur(gray,(13,13),5)

cns,_ = cv2.findContours(gray.copy(), cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)

hull = []

for i in range(0,len(cns)):
    hull.append(cv2.convexHull(cns[i], False))

imageDrawing = np.zeros((img.shape[0], img.shape[1], 3), np.uint8)

for i in range(len(cns)):
    convexArea = cv2.contourArea(hull[i])
    normalArea = cv2.contourArea(cns[i])
    if normalArea/convexArea < 0.9:
        cv2.drawContours(imageDrawing, cns, i, (0, 255, 0),3)

plt.figure(), plt.imshow(imageDrawing,"gray"), plt.title("Output Image")
plt.show()
