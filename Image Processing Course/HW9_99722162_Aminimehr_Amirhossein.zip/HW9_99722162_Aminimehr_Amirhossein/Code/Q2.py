import pandas as pd
import numpy as np

def bb_intersection_over_union(boxA, boxB):
    # determine the (x, y)-coordinates of the intersection rectangle
    xA = max(boxA[0], boxB[0])

    yA = max(boxA[1], boxB[1])

    xB = min(boxA[2]+boxA[0], boxB[2]+boxB[0])

    yB = min(boxA[3]+boxA[1], boxB[3]+boxB[1])

    # compute the area of intersection rectangle
    interArea = max(0, xB - xA) * max(0, yB - yA)
    # compute the area of both the prediction and ground-truth
    # rectangles
    boxAArea = (boxA[2]) * (boxA[3])
    boxBArea = (boxB[2]) * (boxB[3])
    # compute the intersection over union by taking the intersection
    # area and dividing it by the sum of prediction + ground-truth
    # areas - the interesection area
    iou = interArea / float(boxAArea + boxBArea - interArea)


    # return the intersection over union value
    return iou

detections = pd.read_excel('detections.xlsx', sheetname=0)
detectionsX = detections['x'].tolist()
detectionsY = detections['y'].tolist()
detectionsW = detections['w'].tolist()
detectionsH = detections['h'].tolist()
detectionsScore = detections['score'].tolist()

groundTruth = pd.read_excel('ground-truth.xlsx', sheetname=0)
groundTruthX = groundTruth['x'].tolist()
groundTruthY = groundTruth['y'].tolist()
groundTruthW = groundTruth['w'].tolist()
groundTruthH = groundTruth['h'].tolist()

counterGroundTruth = np.zeros(len(groundTruthX))


counterDetections = np.zeros(len(detectionsX))


scores = detectionsScore


scoreThreshholds = []

for score in scores:
    scoreThreshholds.append(score-0.01)
scoreThreshholds.sort()


detectionsList = []
groundTruthList = []

for i in range (len(detectionsX)):
    detectionsList.append([detectionsX[i],detectionsY[i],detectionsW[i],detectionsH[i],detectionsScore[i]])

for i in range (len(groundTruthX)):
    groundTruthList.append([groundTruthX[i],groundTruthY[i],groundTruthW[i],groundTruthH[i]])


detectionsList = sorted(detectionsList,key=lambda l:l[4], reverse=True)



AP = [0.25,0.5,0.75]

TP25 = np.zeros(len(scoreThreshholds))
FP25 = np.zeros(len(scoreThreshholds))
FN25 = np.zeros(len(scoreThreshholds))
AP25 = np.zeros(len(scoreThreshholds))
precision25 = np.zeros(len(scoreThreshholds))
recall25 = np.zeros(len(scoreThreshholds))

TP50 = np.zeros(len(scoreThreshholds))
FP50 = np.zeros(len(scoreThreshholds))
FN50 = np.zeros(len(scoreThreshholds))
AP50 = np.zeros(len(scoreThreshholds))
precision50 = np.zeros(len(scoreThreshholds))
recall50 = np.zeros(len(scoreThreshholds))





TP75 = np.zeros(len(scoreThreshholds))
FP75 = np.zeros(len(scoreThreshholds))
FN75 = np.zeros(len(scoreThreshholds))
AP75 = np.zeros(len(scoreThreshholds))
precision75 = np.zeros(len(scoreThreshholds))
recall75 = np.zeros(len(scoreThreshholds))

detectionsList.reverse()

for i in range (len(AP)):
    for j in range (len(scoreThreshholds)):
        counterGroundTruth = np.zeros(len(groundTruthX))
        counterDetections = np.zeros(len(detectionsX))
        for n in range(len(detectionsList)):
            for m in range (len(groundTruthList)):

                IOU = bb_intersection_over_union(detectionsList[n][0:4],groundTruthList[m])

                if AP[i] == 0.25:

                    if IOU >= AP[i] and detectionsList[n][4] >= scoreThreshholds[j]:
                        TP25[j] += 1
                        counterGroundTruth[m] += 1
                        counterDetections[n] += 1
                    elif IOU < AP[i] and detectionsList[n][4] >= scoreThreshholds[j]:
                        FP25[j] += 1

                elif AP[i] == 0.5:
                    if IOU >= AP[i] and detectionsList[n][4] >= scoreThreshholds[j]:
                        TP50[j] += 1
                        counterGroundTruth[m] += 1
                        counterDetections[n] += 1
                    if IOU < AP[i] and detectionsList[n][4] >= scoreThreshholds[j]:
                        FP50[j] += 1

                elif AP[i] == 0.75:
                    if IOU >= AP[i] and detectionsList[n][4] >= scoreThreshholds[j]:
                        TP75[j] += 1
                        counterGroundTruth[m] += 1
                        counterDetections[n] += 1
                    if IOU < AP[i] and detectionsList[n][4] >= scoreThreshholds[j]:
                        FP75[j] += 1




        if AP[i] == 0.25:

            sum = ((FP25[j] + TP25[j])/5) - TP25[j]
            FP25[j] = sum
            FN25[j] = np.count_nonzero(counterGroundTruth==0)
            precision25[j]  = TP25[j]/(TP25[j]+FP25[j])
            recall25[j] = TP25[j]/(TP25[j]+FN25[j])
            AP25[j] = 2*(precision25[j]*recall25[j])/(precision25[j]+recall25[j])

        elif AP[i] == 0.5:

            sum = ((FP50[j] + TP50[j])/5) - TP50[j]
            FP50[j] = sum
            FN50[j] = np.count_nonzero(counterGroundTruth==0)
            precision50[j]  = TP50[j]/(TP50[j]+FP50[j])
            recall50[j] = TP50[j]/(TP50[j]+FN50[j])
            AP50[j] = 2*(precision50[j]*recall50[j])/(precision50[j]+recall50[j])

        elif AP[i] == 0.75:
            sum = ((FP75[j] + TP75[j])/5) - TP75[j]
            FP75[j] = sum
            FN75[j] = np.count_nonzero(counterGroundTruth==0)
            precision75[j] = TP75[j] / (TP75[j] + FP75[j])
            recall75[j] = TP75[j] / (TP75[j] + FN75[j])
            AP75[j] = 2 * (precision75[j] * recall75[j]) / (precision75[j] + recall75[j])



print("True Positives for AP25: " + str(TP25))
print("False Negatives for AP25: " + str(FN25))
print("False Positive for AP25: " + str(FP25))

print("Precision for AP25: " + str(precision25))
print("Recall for AP25: " + str(recall25))

print("AP25 List: " + str(AP25))
print("AP25: " + str(np.sum(AP25)/8))

import matplotlib.pyplot as plt

plt.plot(recall25,precision25)
plt.title('AP25')
plt.show()

print("\n"+"\n")


print("True Positives for AP50: " + str(TP50))
print("False Negatives for AP50: " + str(FN50))
print("False Positive for AP50: " + str(FP50))

print("Precision for AP50: " + str(precision50))
print("Recall for AP50: " + str(recall50))

print("AP50 List: " + str(AP50))
print("AP50: " + str(np.sum(AP50)/8))

plt.plot(recall50,precision50)
plt.title('AP50')
plt.show()


print("\n"+"\n")


print("True Positives for AP75: " + str(TP75))
print("False Negatives for AP75: " + str(FN75))
print("False Positive for AP75: " + str(FP75))

print("Precision for AP75: " + str(precision75))
print("Recall for AP75: " + str(recall75))

print("AP75 List: " + str(AP75))
print("AP75: " + str(np.sum(AP75)/8))

plt.plot(recall75,precision75)
plt.title('AP75')
plt.show()