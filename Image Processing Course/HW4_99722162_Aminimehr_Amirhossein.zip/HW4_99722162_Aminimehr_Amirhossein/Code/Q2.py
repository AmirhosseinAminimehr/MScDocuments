import numpy as np
import cv2
import matplotlib.pyplot as plt
from scipy.fftpack import dctn, idct
from numpy import empty



def idct2(b):
    M = b.shape[0]
    N = b.shape[1]
    a = empty([M,N],float)
    y = empty([M,N],float)

    for i in range(M):
        a[i,:] = idct(b[i,:])
    for j in range(N):
        y[:,j] = idct(a[:,j])

    return y


quantize_matrix = np.array([[16,11,10,16,24,40,51,61],
                            [12,12,14,19,26,58,60,55],
                            [14,13,16,24,40,57,69,56],
                            [14,17,22,29,51,87,80,62],
                            [18,22,37,56,68,109,103,77],
                            [24,35,55,64,81,104,113,92],
                            [49,64,78,87,103,121,120,101],
                            [72,92,95,98,112,100,130,99]])

sequence = [-40.0, 8.0, 7.0, 1.0, 5.0, 1.0, -1.0, 1.0, 1.0, -1.0, 0.0, -0.0, 1.0]


def sequence_to_block(sequence):
    ### Implement this!!
    rows = len(quantize_matrix)
    columns = len(quantize_matrix[0])
    block = np.zeros((rows, columns))
    sequenceZeroAddNum = columns * rows - len(sequence)

    for i in range(0,sequenceZeroAddNum):
        sequence.append(0)

    newSequence = [[] for i in range(rows+columns-1)]

    for i in range(rows):
        for j in range(columns):
            sum = i + j
            newSequence[sum].append(0)

    counter = 0
    for i in range(len(newSequence)):
        for j in range(len(newSequence[i])):
            newSequence[i][j] = sequence[counter]
            counter += 1

    for i in range(rows):
        for j in range(columns):
            sum = i + j
            if (sum % 2 != 0):
                # add at beginning
                block[i][j] = newSequence[sum][0]
                del newSequence[sum][0]
            else:
                # add at end of the list
                block[i][j] = newSequence[sum][-1]
                del newSequence[sum][-1]

    return block



def inverse_transform(block):
    ## Implement this!!
    inverseQuantizeMatrix = np.multiply(block,quantize_matrix)
    invertedDCTMatrix = idct2(inverseQuantizeMatrix)
    return invertedDCTMatrix




invertedSequenceMatrix = sequence_to_block(sequence)
invertedJpeg = inverse_transform(invertedSequenceMatrix)

plt.imshow(invertedJpeg)
plt.show()


cv2.imwrite("Q2.bmp",invertedJpeg)

### Decode the sequence and generate a 8x8 image and save it as a BMP file

