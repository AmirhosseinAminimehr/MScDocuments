import numpy as np



def compute_histogram(image):
    histogram = np.zeros((256), np.int)
    for i in image:
        for j in i:
            histogram[int(j)] += 1
    return histogram

def entropy(histogram):
    pHistogram = []
    entropy = 0
    for hist in histogram:
        pHistogram.append(hist/np.sum(histogram))
    for p in pHistogram:
        if p != 0:
            entropy += p*np.log2((1/p))
    return entropy


def erms(image1,image2):
    ermsValue = 0
    M = len(image1)
    N = len(image1[0])
    for i in range(M):
        for j in range(N):
            ermsValue += (image1[i][j] - image2[i][j])**2
    ermsValue = (ermsValue/(M*N))**(1/2)
    return ermsValue

def snr(image1,image2):
    snr = 0
    sum = 0
    M = len(image1)
    N = len(image1[0])
    for i in range(M):
        for j in range(N):
            snr += (image1[i][j] - image2[i][j])**2
            sum += (image1[i][j])**2
    snr = sum/snr
    return snr


barcodeImage = [[2,1,254,2,254,255],[2,2,255,2,252,253],[3,0,253,3,255,251],[2,1,255,1,254,253]]

compressedBarcodeImage = np.zeros((len(barcodeImage),len(barcodeImage[0])))

for i in range (0,len(barcodeImage)):
    for j in range (0,len(barcodeImage[0])):
        if barcodeImage[i][j] > 128:
            compressedBarcodeImage[i][j] = 0
        else:
            compressedBarcodeImage[i][j] = 1


barcodeImage = np.array(barcodeImage)

imageHistogram = compute_histogram(barcodeImage)

imageEntropy = entropy(imageHistogram)

compressedBarcodeImage = np.array(compressedBarcodeImage)

compressedImageHistogram = compute_histogram(compressedBarcodeImage)

compressedImageEntropy = entropy(compressedImageHistogram)

print("Entropy of image: " + str(imageEntropy))

print("C of Image & Compressed image: " + str(imageEntropy/compressedImageEntropy))

print("ERMS of Image & Compressed image: " + str(erms(barcodeImage,compressedBarcodeImage)))

print("SNR of Image & Compressed image: " + str(snr(barcodeImage,compressedBarcodeImage)))


secondLevelCompressedBarcode = compressedBarcodeImage[0]

secondLevelCompressedBarcodeImage = []

for i in range (len(secondLevelCompressedBarcode)):
    secondLevelCompressedBarcodeImage.append([])
    secondLevelCompressedBarcodeImage[i].append(int(secondLevelCompressedBarcode[i]))

secondLevelCompressedBarcodeImage = np.array(secondLevelCompressedBarcodeImage)

secondLevelCompressedImageHistogram = compute_histogram(secondLevelCompressedBarcodeImage)

secondLevelCompressedImageEntropy = entropy(secondLevelCompressedImageHistogram)

C = (imageEntropy*barcodeImage.shape[0]*barcodeImage.shape[1])/(secondLevelCompressedImageEntropy*secondLevelCompressedBarcodeImage.shape[0]*secondLevelCompressedBarcodeImage.shape[1])

print("C of Image & Second Level Compressed image: " + str(C))


