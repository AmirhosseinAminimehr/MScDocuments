import numpy as np
import cv2
from scipy.fftpack import fft2, ifft2
import matplotlib.pyplot as plt


def plot_histogram(original_image):
    f, axes = plt.subplots(2,1)
    axes[0].imshow(original_image, 'gray')
    histogram = axes[1].hist(original_image.flatten())
    plt.tight_layout()
    plt.show()

def compute_histogram(image):
    histogram = np.zeros((256), np.int)
    for i in image:
        for j in i:
            histogram[j] += 1
    return histogram


### Load input image and sensor image -> g(x, y) & h(x, y)
inputImage = cv2.imread('cam_1.bmp',cv2.IMREAD_GRAYSCALE)
sensorImage = cv2.imread('sensor.bmp',cv2.IMREAD_GRAYSCALE)

### Rescale (0 - 255 -> 0 - 1) & Normalize sensor image
normalSensorImage = np.divide(sensorImage,np.sum(sensorImage))

### 2D-FFT of input image -> G(u, v)
inputImageDFT = fft2(inputImage)


### 2D-FFT of sensor image -> H(u, v)
sensorImageDFT = fft2(normalSensorImage)

### Inverse filtering -> F_hat(u, v)
unnoisedImage = np.divide(inputImageDFT,sensorImageDFT)

### 2D-iFFT of the filtering result -> f_hat(x, y)
unnoisedImageIDFT = ifft2(unnoisedImage)

### Save to file & plot if you want!
plt.imshow(abs(unnoisedImageIDFT),cmap='gray')
plt.show()

cv2.imwrite("Q4FirstImageUnnoised.jpg",abs(unnoisedImageIDFT))


### Load input image and sensor image -> g(x, y) & h(x, y)
input2Image = cv2.imread('cam_2.bmp',cv2.IMREAD_GRAYSCALE)
sensorImage = cv2.imread('sensor.bmp',cv2.IMREAD_GRAYSCALE)

### Rescale (0 - 255 -> 0 - 1) & Normalize sensor image
normalSensorImage = np.divide(sensorImage,np.sum(sensorImage))

### 2D-FFT of input image -> G(u, v)
input2ImageDFT = fft2(input2Image)

### 2D-FFT of sensor image -> H(u, v)
sensorImageDFT = fft2(normalSensorImage)

### Inverse filtering -> F_hat(u, v)
unnoised2Image = np.divide(input2ImageDFT,sensorImageDFT)

### 2D-iFFT of the filtering result -> f_hat(x, y)
unnoised2ImageIDFT = ifft2(unnoised2Image)

### Save to file & plot if you want!
plt.imshow(abs(unnoised2ImageIDFT),cmap='gray')
plt.show()

cv2.imwrite("Q4SecondImageUnnoised.jpg",abs(unnoised2ImageIDFT))

partOfImage2 = input2Image[165:205,55:90]

plot_histogram(abs(partOfImage2))

print("Mean of the noise: " + str(np.mean(partOfImage2)))

print("Variance of the noise: " + str(np.var(partOfImage2)))