import matplotlib.pyplot as plt
import math
import cv2
import numpy as np

img = cv2.imread('comb.jpg')

I = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

I = cv2.GaussianBlur(I, (3, 3), 0,0,cv2.BORDER_DEFAULT)

sobelX = cv2.Sobel(I, cv2.CV_64F, 1, 0, ksize=3)
sobelY = cv2.Sobel(I, cv2.CV_64F, 0, 1, ksize=3)

sobel = np.zeros((sobelX.shape[0], sobelX.shape[1]))
sobel = abs(sobelX) + abs(sobelY)
sobel[sobel >= 80] = 255
sobel[sobel < 80] = 0

sobeltetta = np.arctan2(sobelX,sobelY)

img = sobel
plt.imshow(img)
img_shape = img.shape
x_max = img_shape[0]
y_max = img_shape[1]
r_min = 0.0
r_max = math.hypot(x_max, y_max)

r_dim = 800
theta_dim = 800

hough_space = np.zeros((r_dim,5000))

for x in range(x_max):
    for y in range(y_max):
        theta_max = 1000 * (1.0 * (sobeltetta[x][y] + 1))
        theta_min = 1000 * (1.0 * (sobeltetta[x][y] - 1))
        if img[x,y] == 255:
            for itheta in range(int(theta_min),int(theta_max)):
                theta = itheta/1000
                r = x * math.cos(theta) + y * math.sin(theta)
                ir = r_dim * ( 1.0 * r ) / r_max
                hough_space[int(ir)][int(itheta)] = hough_space[int(ir)][int(itheta)] + 1

plt.imshow(hough_space, origin='lower')
plt.show()

