import cv2
from scipy.fftpack import fft2, ifft2, ifftshift
import numpy as np

def WienerTransfer(inputImage, sensorImage,K):
  normalSensorImage = sensorImage / np.sum(sensorImage)

  inputImageDFT = fft2(inputImage)
  sensorImageDFT = fft2(ifftshift(normalSensorImage))

  unnoisedImage = inputImageDFT * (abs(sensorImageDFT) ** 2 / (((abs(sensorImageDFT) ** 2) + K) * sensorImageDFT))
  unnoisedImageIDFT = abs(ifft2(unnoisedImage))

  return unnoisedImageIDFT

### Load input image and sensor image -> g(x, y) & h(x, y)
inputImage = cv2.imread("Khayyam.jpg")
sensorImage = cv2.imread("psf1.bmp", cv2.IMREAD_GRAYSCALE)

inputImageR = inputImage[:,:,0]
inputImageG = inputImage[:,:,1]
inputImageB = inputImage[:,:,2]

unnoisedImageR = WienerTransfer(inputImageR, sensorImage,0.002)
unnoisedImageG = WienerTransfer(inputImageG, sensorImage,0.002)
unnoisedImageB = WienerTransfer(inputImageB, sensorImage,0.002)

unnoisedImage = cv2.merge([unnoisedImageR, unnoisedImageG, unnoisedImageB])

### Save to file & plot if you want!
cv2.imwrite("unnoisedKhayyam.jpg", unnoisedImage)


