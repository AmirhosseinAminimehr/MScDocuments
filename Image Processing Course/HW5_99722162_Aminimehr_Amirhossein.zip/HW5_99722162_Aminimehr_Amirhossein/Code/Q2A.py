import cv2
import numpy as np

# if 0 didnt work try different values. ie. 1,2,3,...
cam_id = 0

cap = cv2.VideoCapture(cam_id)

while True:
    ret, IRGB = cap.read()
    I = cv2.cvtColor(IRGB, cv2.COLOR_BGR2GRAY)
    I = cv2.GaussianBlur(I, (3, 3), 0,0,cv2.BORDER_DEFAULT)
    sobelX = cv2.Sobel(I, cv2.CV_64F, 1, 0, ksize=3)
    sobelY = cv2.Sobel(I, cv2.CV_64F, 0, 1, ksize=3)
    sobel = np.zeros((sobelX.shape[0], sobelX.shape[1]))
    sobel = abs(sobelX) + abs(sobelY)
    sobel[sobel >= 80] = 255
    sobel[sobel < 80] = 0
    cv2.imshow("My Camera", sobel)

    # Press 'e' to exit
    if cv2.waitKey(1) & 0xFF == ord('e'):
        break

cap.release()
cv2.destroyAllWindows()