import cv2
import numpy as np

# if 0 didnt work try different values. ie. 1,2,3,...
cam_id = 0

cap = cv2.VideoCapture(cam_id)

while True:
    ret, I = cap.read()

    I = cv2.GaussianBlur(I,(5,5),0)

    canny = cv2.Canny(I,60,120)

    cv2.imshow("My Camera", canny)

    # Press 'e' to exit
    if cv2.waitKey(1) & 0xFF == ord('e'):
        break

cap.release()
cv2.destroyAllWindows()