import cv2
import numpy as np

def hconcat_resize(img_list,interpolation = cv2.INTER_CUBIC):
    h_min = min(img.shape[0] for img in img_list)
    im_list_resize = [cv2.resize(img, (int(img.shape[1] * h_min / img.shape[0]), h_min), interpolation=interpolation)for img in img_list]
    return cv2.hconcat(im_list_resize)

einstein = cv2.imread('einstein.jpg', cv2.IMREAD_GRAYSCALE)
peppers = cv2.imread('peppers.jpg', cv2.IMREAD_GRAYSCALE)


einsteinHalf = einstein[:, 0:126]
peppersHalf = peppers[:, 126:]

J = hconcat_resize([einsteinHalf, peppersHalf])

cv2.imshow('peptein', J)
cv2.imwrite('peptein.jpg', J)

J_neg = 255 - J
cv2.imshow('negative_einstein', J_neg)
cv2.imwrite('negative_einstein.jpg', J_neg)

peppersColor = cv2.imread('peppers_color.png')

bluePeppers = peppersColor.copy()
bluePeppers[:, :, 1] = 0
bluePeppers[:, :, 2] = 0

greenPeppers = peppersColor.copy()
greenPeppers[:, :, 0] = 0
greenPeppers[:, :, 2] = 0

redPeppers = peppersColor.copy()
redPeppers[:, :, 0] = 0
redPeppers[:, :, 1] = 0

cv2.imshow('bluePeppers', bluePeppers)
cv2.imwrite('bluePeppers.jpg',bluePeppers)

cv2.imshow('greenPeppers', greenPeppers)
cv2.imwrite('greenPeppers.jpg',greenPeppers)

cv2.imshow('redPeppers', redPeppers)
cv2.imwrite('redPeppers.jpg',redPeppers)

cv2.waitKey()