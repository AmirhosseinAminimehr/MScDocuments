import cv2
import numpy as np
import matplotlib.pyplot as plt

def plot_histogram(original_image):
    f, axes = plt.subplots(2,1)
    axes[0].imshow(original_image, 'gray', vmin=0, vmax=255)
    histogram = axes[1].hist(original_image.flatten(), range=(0,255), bins=255)
    plt.tight_layout()
    plt.show()

def clahe(image):
    cla = cv2.createCLAHE()
    finalImage = cla.apply(image)
    return finalImage

tsukuba_lImage = cv2.imread('../HW2_Supplements/images/tsukuba_l.png', cv2.IMREAD_GRAYSCALE)

tsukuba_lClaheImage = clahe(tsukuba_lImage)
plot_histogram(tsukuba_lClaheImage)

cv2.waitKey()