import cv2
import numpy as np
import matplotlib.pyplot as plt

class ColorLevel:
    F = []
    def __init__(self):
        self.count = 0
        self.pixels = []

def plot_histogram(original_image):
    f, axes = plt.subplots(2,1)
    axes[0].imshow(original_image, 'gray', vmin=0, vmax=255)
    histogram = axes[1].hist(original_image.flatten(), range=(0,255), bins=255)
    plt.tight_layout()
    plt.show()

def compute_histogram(image):
    histogram = np.zeros((256), np.int)
    for i in image:
        for j in i:
            histogram[j] += 1
    return histogram

def histogram_stretching(image):
    h = compute_histogram(image)
    out_image = image.copy()

    min_color = 0
    max_color = 255
    for i in range(0,256):
        if(h[i]!= 0):
            min_color = i
            break
    for i in range(255,-1,-1):
        if (h[i] != 0):
            max_color = i
            break
    for i in range(0,len(out_image)):
        for j in range(0,len(out_image[i])):
            co_ef = 255/(max_color-min_color)
            out_image[i][j] = int(co_ef * (out_image[i][j] - min_color))

    return out_image

def histogram_cut_stretching(image):
    h = compute_histogram(image)
    copy_image = image.copy()
    out_image = np.zeros((len(copy_image),len(copy_image[1])))
    min_color = 0
    max_color = 255

    ImageColorNumber = sum(h)

    flag = 0
    for i in range(0,256):
        if(h[i]!= 0 ):
            flag += h[i]
            min_color = i
            if(flag > ImageColorNumber*0.01):
                break
    flag = 0
    for i in range(255,-1,-1):
        if (h[i] != 0):
            flag += h[i]
            max_color = i
            if(flag > ImageColorNumber*0.01):
                break

    for i in range(0,len(copy_image)):
        for j in range(0,len(copy_image[i])):
            co_ef = 255/(max_color-min_color)
            out_image[i][j] = co_ef * (copy_image[i][j] - min_color)
            if (out_image[i][j]<0):
                out_image[i][j] = 0
            if (out_image[i][j]>255):
                out_image[i][j] = 255
    return out_image

def histogram_equalization(image):

    out_image = image.copy()

    ColorLevel.F = []

    hist = []
    for i in range(0,256):
        temp = ColorLevel()
        hist.append(temp)


    for i in range(0, len(image)):
        for j in range(0, len(image[i])):
            hist[image[i][j]].count += 1
            hist[image[i][j]].pixels.append( (i,j) )

    for i in hist:
        if (len(ColorLevel.F) == 0):
            ColorLevel.F.append(i.count)
        else:
            ColorLevel.F.append(i.count + ColorLevel.F[len(ColorLevel.F) - 1])

    co_ef = 255 / (len(image) * len(image[0]))

    for i in range(0,len(ColorLevel.F)):
        ColorLevel.F[i] = int(co_ef * ColorLevel.F[i])

    for i in range(0,256):
        col_level = hist[i]
        for j in range(0,len(col_level.pixels)):
            x,y = col_level.pixels[j]
            out_image[x][y] = ColorLevel.F[i]

    return out_image



mapImage = cv2.imread('../HW2_Supplements/images/map.jpg', cv2.IMREAD_GRAYSCALE)

plot_histogram(mapImage)

mapImageScretched = histogram_stretching(mapImage)
plot_histogram(mapImageScretched)

mapImageCutedScretched = histogram_cut_stretching(mapImage)
plot_histogram(mapImageCutedScretched)

mapImageEqualized = histogram_equalization(mapImage)
plot_histogram(mapImageEqualized)

cv2.waitKey(2000)




tsukuba_lImage = cv2.imread('../HW2_Supplements/images/tsukuba_l.png', cv2.IMREAD_GRAYSCALE)

plot_histogram(tsukuba_lImage)

tsukuba_lImageScretched = histogram_stretching(tsukuba_lImage)
plot_histogram(tsukuba_lImageScretched)

tsukuba_lImageCutedScretched = histogram_cut_stretching(tsukuba_lImage)
plot_histogram(tsukuba_lImageCutedScretched)

tsukuba_lImageEqualized = histogram_equalization(tsukuba_lImage)
plot_histogram(tsukuba_lImageEqualized)

cv2.waitKey(2000)




Unequalized_Hawkes_BayImage = cv2.imread('../HW2_Supplements/images/Unequalized_Hawkes_Bay.jpg', cv2.IMREAD_GRAYSCALE)

plot_histogram(Unequalized_Hawkes_BayImage)

Unequalized_Hawkes_BayImageScretched = histogram_stretching(Unequalized_Hawkes_BayImage)
plot_histogram(Unequalized_Hawkes_BayImageScretched)

Unequalized_Hawkes_BayImageCutedScretched = histogram_cut_stretching(Unequalized_Hawkes_BayImage)
plot_histogram(Unequalized_Hawkes_BayImageCutedScretched)

Unequalized_Hawkes_BayImageEqualized = histogram_equalization(Unequalized_Hawkes_BayImage)
plot_histogram(Unequalized_Hawkes_BayImageEqualized)

cv2.waitKey()

