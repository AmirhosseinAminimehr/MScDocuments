import numpy as np
import matplotlib.pyplot as plt
import cv2
import math

# implement a function that returns a gaussian kernel
def make_gaussian(size=3, std=1):
    kernel = []
    sum = 0
    for i in range (0,size):
        kernel.append([])
        for j in range (0,size):
            middle = (size-1)/2
            kernel[i].append(math.exp(((int(middle)-i)**2+(int(middle)-j)**2)/((2*(std**2))*(-1))))
            sum += kernel[i][j]
    for i in range (0,size):
        for j in range (0, size):
            kernel[i][j] = kernel[i][j]/sum
    return kernel

# implement a 2D convolution
def convolve2d(image, kernel):
    # You do not need to modify these, but feel free to implement your own
    kernel       = np.flipud(np.fliplr(kernel))  # Flip the kernel, if it's symmetric it does not matter
    kernel_width = kernel.shape[0]
    kernel_height= kernel.shape[1]
    padding      = (kernel_width - 1)
    offset       = padding // 2
    output       = np.zeros_like(image)
    # Add zero padding to the input image
    image_padded = np.zeros((image.shape[0] + padding, image.shape[1] + padding))
    image_padded[offset:-offset, offset:-offset] = image

    # implement the convolution inside the inner for loop
    for y in range(image.shape[0]):
        for x in range(image.shape[1]):
            sum = 0
            for i in range(0,len(kernel)):
                for j in range(0,len(kernel)):
                    sum = sum + kernel[i][j] * image_padded[y-i][x-j]
            output[y][x] = sum
            # Convolution - Your code here
            continue
    return output

kernel = make_gaussian(19,3)
azadiImage = cv2.imread('../HW2_Supplements/Azadi.jpg', cv2.IMREAD_GRAYSCALE)

invertAzadiImage = 255 - azadiImage
bluredAzadiImage = convolve2d(invertAzadiImage,kernel)

invertBluredAzadiImage = 255 - bluredAzadiImage

sketchedAzadiImage = cv2.divide(azadiImage,invertBluredAzadiImage,scale=256)

cv2.imshow('Sketched Azadi', sketchedAzadiImage)
cv2.waitKey()