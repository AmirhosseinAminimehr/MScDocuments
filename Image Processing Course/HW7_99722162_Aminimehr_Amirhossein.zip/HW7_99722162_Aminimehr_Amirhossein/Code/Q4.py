from HodaDatasetReader import read_hoda_dataset
from tensorflow.keras.models import Sequential
import tensorflow.keras.layers as layers
import numpy as np
from sklearn import metrics

def one_hot_encoder(y):
    y = y.reshape(-1)
    num_samples = y.shape[0]
    max_label = np.max(y)
    one_hot = np.zeros((num_samples, int(max_label) + 1))
    one_hot[np.arange(num_samples), y] = 1

    return one_hot


print('Reading Train 60000.cdb ...')
train_images, train_labels = read_hoda_dataset(dataset_path='./DigitDB/Train 60000.cdb',images_height=32,images_width=32,one_hot=True)

print('Reading Test 20000.cdb ...')
test_images, test_labels = read_hoda_dataset(dataset_path='./DigitDB/Test 20000.cdb',images_height=32,images_width=32,one_hot=True)

X_train = np.array(train_images)
X_test = np.array(test_images)
Y_train = np.array(train_labels)
Y_test = np.array(test_labels)

print(X_train.shape, Y_train.shape)

X_train = X_train.reshape(60000,32,32,1)
X_test = X_test.reshape(20000,32,32,1)

num_classes = 10

model = Sequential()
model.add(layers.Conv2D(32, (3, 3), activation='relu', input_shape = (32,32,1)))
model.add(layers.Conv2D(filters=32, kernel_size=(3, 3), activation='relu'))
model.add(layers.MaxPool2D(2,2))
model.add(layers.Conv2D(filters=32, kernel_size=(3, 3), activation='relu'))
model.add(layers.Conv2D(filters=32, kernel_size=(3, 3), activation='relu'))
model.add(layers.MaxPool2D(2,2))
model.add(layers.Flatten(input_shape=X_train[0].shape))
model.add(layers.Dense(128, activation='relu'))
model.add(layers.Dense(units=num_classes, activation='softmax'))

# model.add(layers.Input(shape=X_train[0].shape))
# model.add(layers.Conv2D(filters=128, kernel_size=(7, 7), activation='relu'))
# model.add(layers.Conv2D(filters=64, kernel_size=(5, 5), activation='relu'))
# model.add(layers.MaxPool2D())
# model.add(layers.Flatten(input_shape=X_train[0].shape))
# model.add(layers.Dense(units=num_classes, activation='softmax'))

# model = Sequential()
# model.add(layers.Dense(64, input_shape=input_shape, activation='relu') )
# model.add(layers.Dense(100, activation='relu'))
# model.add(layers.Dense(num_classes, activation='softmax'))

# Configure the model and start training
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

print(model.summary())

model.fit(X_train, Y_train, epochs=10, batch_size=40, verbose=1)

# Test the model after training
test_results = model.evaluate(X_test, Y_test, verbose=1)
print('Test results - Loss:' + str({test_results[0]}) +  '- Accuracy:' + str({test_results[1]}))

predicts = model.predict(X_test)

matrix = metrics.confusion_matrix(Y_test.argmax(axis=1), predicts.argmax(axis=1))

print(matrix)