from sklearn.svm import SVC
from HodaDatasetReader import read_hoda_dataset
import numpy as np
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score



def LBP(img):
    input_img = img.copy()
    gray_image = input_img
    imgLBP = np.zeros_like(gray_image)
    neighboor = 3
    for ih in range(0, input_img.shape[0] - neighboor):
        for iw in range(0, input_img.shape[1] - neighboor):
            img = gray_image[ih:ih + neighboor, iw:iw + neighboor]
            center = img[1, 1]
            img01 = (img >= center) * 1.0
            img01_vector = img01.flatten()
            img01_vector = np.delete(img01_vector, 4)
            where_img01_vector = np.where(img01_vector)[0]
            if len(where_img01_vector) >= 1:
                num = np.sum(2 ** where_img01_vector)
            else:
                num = 0
            imgLBP[ih + 1, iw + 1] = num
    return imgLBP



print('Reading Train 60000.cdb ...')
train_images, train_labels = read_hoda_dataset(dataset_path='./DigitDB/Train 60000.cdb',images_height=32,images_width=32,one_hot=False)

print('Reading Test 20000.cdb ...')
test_images, test_labels = read_hoda_dataset(dataset_path='./DigitDB/Test 20000.cdb',images_height=32,images_width=32,one_hot=False)

data_train = np.array(train_images).astype('uint8')
data_test = np.array(test_images).astype('uint8')

img_length = 32
data_train = data_train.reshape(-1,img_length,img_length)
data_test = data_test.reshape(-1,img_length,img_length)

# plt.imshow(data[51])
data_gray_train = np.array(data_train)
data_gray_test = np.array(data_test)

print(np.array(data_gray_train).shape)
print(np.array(data_gray_test).shape)

features_training = []
for image in data_gray_train:

    lbp_img = LBP(image)
    features_training.append(lbp_img.flatten())


features_test = []
for image in data_gray_test:

    lbp_img = LBP(image)
    features_test.append(lbp_img.flatten())


X_train = np.array(features_training)
X_test = np.array(features_test)
Y_train = np.array(train_labels)
Y_test = np.array(test_labels)

svm = SVC(kernel='linear',max_iter=15000)
print(X_train.shape)
svm = svm.fit(X_train, Y_train)

svm_predict = svm.predict(X_test)

svm_score = accuracy_score(Y_test, svm_predict)
print("svm_score :", svm_score)

svm_report = classification_report(Y_test, svm_predict)
print(svm_report)

cm = confusion_matrix(Y_test, svm_predict, labels=[9,8,7,6,5,4,3,2,1,0])
print(cm)