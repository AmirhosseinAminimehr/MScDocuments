from skimage.feature import hog
from sklearn.svm import SVC
from HodaDatasetReader import read_hoda_dataset
import numpy as np
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score



print('Reading Train 60000.cdb ...')
train_images, train_labels = read_hoda_dataset(dataset_path='./DigitDB/Train 60000.cdb',images_height=32,images_width=32,one_hot=False)

print('Reading Test 20000.cdb ...')
test_images, test_labels = read_hoda_dataset(dataset_path='./DigitDB/Test 20000.cdb',images_height=32,images_width=32,one_hot=False)


data_train = np.array(train_images).astype('uint8')
data_test = np.array(test_images).astype('uint8')

img_length = 32
data_train = data_train.reshape(-1,img_length,img_length)
data_test = data_test.reshape(-1,img_length,img_length)

data_gray_train = np.array(data_train)
data_gray_test = np.array(data_test)

print(np.array(data_gray_train).shape)
print(np.array(data_gray_test).shape)

ppc = 8
hog_images_training = []
hog_features_training = []
for image in data_gray_train:
    fd,hog_image = hog(image, orientations=8, pixels_per_cell=(ppc,ppc),cells_per_block=(4, 4),block_norm= 'L2',visualize=True)
    hog_images_training.append(hog_image)
    hog_features_training.append(fd)

ppc = 8
hog_images_test = []
hog_features_test = []
for image in data_gray_test:
    fd,hog_image = hog(image, orientations=8, pixels_per_cell=(ppc,ppc),cells_per_block=(4, 4),block_norm= 'L2',visualize=True)
    hog_images_test.append(hog_image)
    hog_features_test.append(fd)

X_train = np.array(hog_features_training)
X_test = np.array(hog_features_test)
Y_train = np.array(train_labels)
Y_test = np.array(test_labels)

svm = SVC(kernel='linear')
print(X_train.shape)
svm = svm.fit(X_train, Y_train)

svm_predict = svm.predict(X_test)

svm_score = accuracy_score(Y_test, svm_predict)
print("svm_score :", svm_score)

svm_report = classification_report(Y_test, svm_predict)
print(svm_report)

cm = confusion_matrix(Y_test, svm_predict, labels=[9,8,7,6,5,4,3,2,1,0])
print(cm)

