from skimage.feature import local_binary_pattern
from sklearn.svm import SVC
from HodaDatasetReader import read_hoda_dataset
import numpy as np
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score



print('Reading Train 60000.cdb ...')
train_images, train_labels = read_hoda_dataset(dataset_path='./drive/MyDrive/Train 60000.cdb',images_height=32,images_width=32,one_hot=False)

print('Reading Test 20000.cdb ...')
test_images, test_labels = read_hoda_dataset(dataset_path='./drive/MyDrive/Test 20000.cdb',images_height=32,images_width=32,one_hot=False)

data_train = np.array(train_images).astype('uint8')
data_test = np.array(test_images).astype('uint8')

img_length = 32
data_train = data_train.reshape(-1,img_length,img_length)
data_test = data_test.reshape(-1,img_length,img_length)

# plt.imshow(data[51])
data_gray_train = np.array(data_train)
data_gray_test = np.array(data_test)

print(np.array(data_gray_train).shape)
print(np.array(data_gray_test).shape)


features_training = []
for image in data_gray_train:
    lbp_img = local_binary_pattern(image, P=8, R=1)
    features_training.append(lbp_img.flatten())


features_test = []
for image in data_gray_test:
    lbp_img = local_binary_pattern(image, P=8, R=1)
    features_test.append(lbp_img.flatten())


X_train = np.array(features_training)
X_test = np.array(features_test)
Y_train = np.array(train_labels)
Y_test = np.array(test_labels)

svm = SVC(kernel='linear',max_iter=15000)
print(X_train.shape)
svm = svm.fit(X_train, Y_train)

svm_predict = svm.predict(X_test)

svm_score = accuracy_score(Y_test, svm_predict)
print("svm_score :", svm_score)

svm_report = classification_report(Y_test, svm_predict)
print(svm_report)

cm = confusion_matrix(Y_test, svm_predict, labels=[9,8,7,6,5,4,3,2,1,0])
print(cm)
