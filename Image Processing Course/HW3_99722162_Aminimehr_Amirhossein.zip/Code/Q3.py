import cv2
import numpy as np
import matplotlib.pyplot as plt
from scipy import fftpack
from numpy import empty


def lowPassFilter(x,y,r):
    lowpfilter = np.zeros((x, y))
    tpa1 = x
    tpa2 = y
    Do = r;
    for i in range(1, tpa1):

        for j in range(1, tpa2):

            if (np.sqrt((i - tpa1 / 2) ** 2 + (j - tpa2 / 2) ** 2) <= Do):
                lowpfilter[i][j] = 1;
    plt.title("Low pass filter Image")
    plt.imshow(lowpfilter)
    plt.show()
    return lowpfilter

def dct2(y):
    M = y.shape[0]
    N = y.shape[1]
    a = empty([M,N],float)
    b = empty([M,N],float)

    for i in range(M):
        a[i,:] = fftpack.dct(y[i,:])
    for j in range(N):
        b[:,j] = fftpack.dct(a[:,j])

    return b

def idct2(b):
    M = b.shape[0]
    N = b.shape[1]
    a = empty([M,N],float)
    y = empty([M,N],float)

    for i in range(M):
        a[i,:] = fftpack.idct(b[i,:])
    for j in range(N):
        y[:,j] = fftpack.idct(a[:,j])

    return y


def shiftDCT(image):
    shiftedNoisyImageDCT = []
    x = len(image)
    y = len(image[1])

    counter = 0
    for i in range(int(x/2),x):

        shiftedNoisyImageDCT.append([])
        for j in range(int(y/2),y):
            shiftedNoisyImageDCT[counter].append(image[i][j])
        for j in range(0,int(y/2)):
            shiftedNoisyImageDCT[counter].append(image[i][j])
        counter = counter + 1

    for i in range(0,int(x/2)):
        shiftedNoisyImageDCT.append([])
        for j in range(int(y/2),y):
            shiftedNoisyImageDCT[counter].append(image[i][j])
        for j in range(0,int(y/2)):
            shiftedNoisyImageDCT[counter].append(image[i][j])
        counter = counter + 1

    return shiftedNoisyImageDCT



noisyImage = cv2.imread('2.jpg',cv2.IMREAD_GRAYSCALE)

plt.title("Noisy image")
plt.imshow(noisyImage, cmap='gray')
plt.show()

noisyImageDCT = dct2(noisyImage)
shiftedNoisyImageDCT = shiftDCT(noisyImageDCT)


lowPassFilterImage = lowPassFilter(512,512,150)

unnoisedImage = np.zeros((512,512))

for i in range(512):
    for j in range(512):
        unnoisedImage[i][j] = lowPassFilterImage[i][j] * shiftedNoisyImageDCT[i][j]


unShiftedImageDCT = shiftDCT(unnoisedImage)
imageDCTInverse = idct2(np.array(unShiftedImageDCT))

plt.title("Unnoised Image")
plt.imshow(imageDCTInverse, cmap='gray')
plt.show()


