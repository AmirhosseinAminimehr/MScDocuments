import cv2
import numpy as np
import matplotlib.pyplot as plt
from scipy import fftpack
from numpy import empty

def dct2(y):
    M = y.shape[0]
    N = y.shape[1]
    a = empty([M,N],float)
    b = empty([M,N],float)

    for i in range(M):
        a[i,:] = fftpack.dct(y[i,:])
    for j in range(N):
        b[:,j] = fftpack.dct(a[:,j])

    return b


def shiftDCT(image):
    shiftedNoisyImageDCT = []
    x = len(image)
    y = len(image[1])

    counter = 0
    for i in range(int(x/2),x):

        shiftedNoisyImageDCT.append([])
        for j in range(int(y/2),y):
            shiftedNoisyImageDCT[counter].append(image[i][j])
        for j in range(0,int(y/2)):
            shiftedNoisyImageDCT[counter].append(image[i][j])
        counter = counter + 1

    for i in range(0,int(x/2)):
        shiftedNoisyImageDCT.append([])
        for j in range(int(y/2),y):
            shiftedNoisyImageDCT[counter].append(image[i][j])
        for j in range(0,int(y/2)):
            shiftedNoisyImageDCT[counter].append(image[i][j])
        counter = counter + 1

    return shiftedNoisyImageDCT


airplaneImage = cv2.imread('1.bmp',cv2.IMREAD_GRAYSCALE)

airplaneDFT = fftpack.fft2(airplaneImage)
airplaneDFTShifted = fftpack.fftshift(airplaneDFT)
airplaneDFTShiftedLog = 20*np.log(np.abs(airplaneDFTShifted))

airplaneDCT = dct2(airplaneImage)
airplaneDCTShifted = shiftDCT(airplaneDCT)
airplaneDCTShiftedLog = 20*np.log(np.abs(airplaneDCTShifted))

plt.title("Airplane image DFT")
plt.imshow(abs(airplaneDFT), cmap='gray')
plt.show()
plt.title("Airplane image shifted DFT")
plt.imshow(abs(airplaneDFTShifted), cmap='gray')
plt.show()
plt.title("Airplane image shifted Log DFT")
plt.imshow(abs(airplaneDFTShiftedLog), cmap='gray')
plt.show()


plt.title("Airplane image DCT")
plt.imshow(abs(airplaneDCT), cmap='gray')
plt.show()
plt.title("Airplane image shifted DCT")
plt.imshow(airplaneDCTShifted, cmap='gray')
plt.show()
plt.title("Airplane image shifted Log DCT")
plt.imshow(airplaneDCTShiftedLog, cmap='gray')
plt.show()


airplaneDFTList = []
airplaneDCTList = []

for row in airplaneDCTShifted:
    for coefficient in row:
        airplaneDCTList.append(abs(coefficient))

for row in airplaneDFTShifted:
    for coefficient in row:
        airplaneDFTList.append(abs(coefficient))

airplaneDCTABS = sorted(np.abs(airplaneDCTList))
airplaneDCTABS.reverse()
airplaneDFTABS = sorted(np.abs(airplaneDFTList))
airplaneDFTABS.reverse()

airplaneDCTABSCS = (np.array(airplaneDCTABS)**2).cumsum()
airplaneDFTABSCS = (np.array(airplaneDFTABS)**2).cumsum()

absSortedDCTImage = []
acsSortedDFTImage = []

for i in range (0,256):
    absSortedDCTImage.append([])
    for j in range (0,256):
        absSortedDCTImage[i].append(airplaneDCTABSCS[i+j])

for i in range (0,256):
    acsSortedDFTImage.append([])
    for j in range (0,256):
        acsSortedDFTImage[i].append(airplaneDFTABSCS[i+j])

plt.title("Abs sorted DCT image")
plt.imshow(absSortedDCTImage, cmap='gray')
plt.show()

plt.title("Abs sorted DFT image")
plt.imshow(acsSortedDFTImage, cmap='gray')
plt.show()

plt.title("Abs sorted DCT plot")
plt.plot(airplaneDCTABSCS)
plt.show()

plt.title("Abs sorted DFT pot")
plt.plot(airplaneDFTABSCS)
plt.show()

cv2.waitKey()
