import numpy as np
import matplotlib.pyplot as plt
import pywt.data
from math import log10, sqrt

def PSNR(original, compressed):
    mse = np.mean((original - compressed) ** 2)
    if(mse == 0):  # MSE is zero means no noise is present in the signal .
                  # Therefore PSNR have no importance.
        return 100
    max_pixel = 255.0
    psnr = 20 * log10(max_pixel / sqrt(mse))
    return psnr

original = plt.imread('3.bmp')

titles = ['Approximation', ' Horizontal detail',
          'Vertical detail', 'Diagonal detail']

coeffs2 = pywt.dwt2(original, 'haar')
LL, (LH, HL, HH) = coeffs2
fig = plt.figure(figsize=(12, 3))
for i, a in enumerate([LL, LH, HL, HH]):
    ax = fig.add_subplot(1, 4, i + 1)
    ax.imshow(a, interpolation="nearest", cmap=plt.cm.gray)
    ax.set_title(titles[i], fontsize=10)
    ax.set_xticks([])
    ax.set_yticks([])


fig.tight_layout()
plt.show()

title = "Approximate image " + str(len(LL)) + "*" + str(len(LL[0]))
plt.title(title)
plt.imshow(LL,interpolation="nearest", cmap=plt.cm.gray)
plt.show()

zeroImage = np.zeros((len(LL),len(LL[0])))

coeffs2 = LL, (zeroImage,zeroImage,zeroImage)

approximationImage = pywt.idwt2(coeffs2, 'haar')

title = "Approximate image " + str(2*len(LL)) + "*" + str(2*len(LL[0]))
plt.title(title)
plt.imshow(approximationImage,interpolation="nearest", cmap=plt.cm.gray)
plt.show()
original = plt.imread('4.bmp')

value = PSNR(original, approximationImage)

print("PSNR is "+ str(value) + " dB")

