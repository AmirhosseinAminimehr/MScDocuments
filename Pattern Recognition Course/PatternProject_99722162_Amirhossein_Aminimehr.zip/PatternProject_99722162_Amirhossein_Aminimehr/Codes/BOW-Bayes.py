import pandas as pd
import matplotlib.pyplot as plt
import nltk
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.preprocessing import LabelBinarizer
from nltk.corpus import stopwords
from bs4 import BeautifulSoup
import re
from nltk.tokenize.toktok import ToktokTokenizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score


# Removing the html strips
def strip_html(text):
    soup = BeautifulSoup(text, "html.parser")
    return soup.get_text()


# Removing the square brackets
def remove_between_square_brackets(text):
    return re.sub('\[[^]]*\]', '', text)


# Removing the noisy text
def denoise_text(text):
    text = strip_html(text)
    text = remove_between_square_brackets(text)
    return text


# Define function for removing special characters
def remove_special_characters(text, remove_digits=True):
    pattern = r'[^a-zA-z0-9\s]'
    text = re.sub(pattern, '', text)
    return text


# Stemming the text
def simple_stemmer(text):
    ps = nltk.porter.PorterStemmer()
    text = ' '.join([ps.stem(word) for word in text.split()])
    return text


# removing the stopwords
def remove_stopwords(text, is_lower_case=False):
    tokens = tokenizer.tokenize(text)
    tokens = [token.strip() for token in tokens]
    if is_lower_case:
        filtered_tokens = [token for token in tokens if token not in stopword_list]
    else:
        filtered_tokens = [token for token in tokens if token.lower() not in stopword_list]
    filtered_text = ' '.join(filtered_tokens)
    return filtered_text


import warnings

warnings.filterwarnings('ignore')

# Importing the training data
imdbTrainData = pd.read_csv('Train.csv')
imdbTestData = pd.read_csv('Test.csv')

# Printing some detailes from the training data
print(imdbTrainData.shape)
print(imdbTrainData.head(10))
print(imdbTrainData.describe())
print(imdbTrainData['label'].value_counts())

# Tokenization of text
tokenizer = ToktokTokenizer()

# Setting English stopwords
nltk.download('stopwords')
stopword_list = nltk.corpus.stopwords.words('english')

# Apply function on review column
imdbTrainData['text'] = imdbTrainData['text'].apply(denoise_text)
imdbTestData['text'] = imdbTestData['text'].apply(denoise_text)

# Apply function on review column
imdbTrainData['text'] = imdbTrainData['text'].apply(remove_special_characters)
imdbTestData['text'] = imdbTestData['text'].apply(remove_special_characters)

# Apply function on review column
imdbTrainData['text'] = imdbTrainData['text'].apply(simple_stemmer)
imdbTestData['text'] = imdbTestData['text'].apply(simple_stemmer)

# set stopwords to english
stop = set(stopwords.words('english'))
print(stop)

# Apply function on review column
imdbTrainData['text'] = imdbTrainData['text'].apply(remove_stopwords)
imdbTestData['text'] = imdbTestData['text'].apply(remove_stopwords)

# normalized train reviews
norm_train_reviews = imdbTrainData.text

# Normalized test reviewssirali
norm_test_reviews = imdbTestData.text

# Count vectorizer for bag of words
CountVectorizer()
cv = CountVectorizer(max_df=0.8, min_df=0.01, max_features=15000)
# #transformed train reviews
cv_train_reviews = cv.fit_transform(norm_train_reviews)
# #transformed test reviews
cv_test_reviews = cv.transform(norm_test_reviews)

print('BOW_cv_train:', cv_train_reviews.shape)
print('BOW_cv_test:', cv_test_reviews.shape)

# transformed sentiment data
train_sentiments = imdbTrainData['label']
test_sentiments = imdbTestData['label']


##########################################################################Bayes Multinomial####################################################
# training the model
mnb = MultinomialNB()
# fitting the svm for bag of words
mnb_bow = mnb.fit(cv_train_reviews, train_sentiments)
print(mnb_bow)

# Predicting the model for bag of words
mnb_bow_predict = mnb.predict(cv_test_reviews)
print(mnb_bow_predict)

# Accuracy score for bag of words
mnb_bow_score = accuracy_score(test_sentiments, mnb_bow_predict)
print("mnb_bow_score :", mnb_bow_score)

# Classification report for bag of words
mnb_bow_report = classification_report(test_sentiments, mnb_bow_predict, target_names=['Positive', 'Negative'])
print(mnb_bow_report)

#confusion matrix for bag of words
cm_bow=confusion_matrix(test_sentiments,mnb_bow_predict,labels=[1,0])
print(cm_bow)

#ROC
from sklearn import datasets, metrics, model_selection, svm
metrics.plot_roc_curve(mnb, cv_test_reviews, test_sentiments)
plt.show()

#AUC
fpr, tpr, thresholds = metrics.roc_curve(test_sentiments, mnb_bow_predict)
print(metrics.auc(fpr, tpr))
####################################################################################################################################################
