import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import nltk
from nltk.corpus import stopwords
from bs4 import BeautifulSoup
import re
from nltk.tokenize.toktok import ToktokTokenizer
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from bert_embedding import BertEmbedding
import itertools


# Removing the html strips
def strip_html(text):
    soup = BeautifulSoup(text, "html.parser")
    return soup.get_text()


# Removing the square brackets
def remove_between_square_brackets(text):
    return re.sub('\[[^]]*\]', '', text)


# Removing the noisy text
def denoise_text(text):
    text = strip_html(text)
    text = remove_between_square_brackets(text)
    return text


# Define function for removing special characters
def remove_special_characters(text, remove_digits=True):
    pattern = r'[^a-zA-z0-9\s]'
    text = re.sub(pattern, '', text)
    return text


# Stemming the text
def simple_stemmer(text):
    ps = nltk.porter.PorterStemmer()
    text = ' '.join([ps.stem(word) for word in text.split()])
    return text


# removing the stopwords
def remove_stopwords(text, is_lower_case=False):
    tokens = tokenizer.tokenize(text)
    tokens = [token.strip() for token in tokens]
    if is_lower_case:
        filtered_tokens = [token for token in tokens if token not in stopword_list]
    else:
        filtered_tokens = [token for token in tokens if token.lower() not in stopword_list]
    filtered_text = ' '.join(filtered_tokens)
    return filtered_text


def Bert(data):
    sentences = re.split('!|\?|\.', data)
    sentences = list(filter(None, sentences))
    result = bert(sentences, 'avg')
    words = []
    for sentence in range(len(result)):
        for word in range(len(result[sentence][1])):
            words.append(result[sentence][1][word])
    feature = [mean(x) for x in zip(*words)]
    return feature


def mean(z):  # used for BERT (word version) and Word2Vec
    return sum(itertools.chain(z)) / len(z)


import warnings

warnings.filterwarnings('ignore')

# Importing the training data
imdbTrainData = pd.read_csv('../MyDrive/Train.csv')
imdbTestData = pd.read_csv('../MyDrive/Test.csv')
imdbValidationData = pd.read_csv('../MyDrive/Valid.csv')

with open('../MyDrive/test.npy', 'wb') as f:
    np.save(f, np.array([1, 2]))
    np.save(f, np.array([1, 3]))

print("save test")

# Printing some detailes from the training data
print(imdbTrainData.shape)
print(imdbTrainData.head(10))
print(imdbTrainData.describe())
print(imdbTrainData['label'].value_counts())

# Tokenization of text
tokenizer = ToktokTokenizer()

# Setting English stopwords
nltk.download('stopwords')
stopword_list = nltk.corpus.stopwords.words('english')  # This command needed ===> python3 -m nltk.downloader stopwords

# Apply function on review column
imdbTrainData['text'] = imdbTrainData['text'].apply(denoise_text)
imdbTestData['text'] = imdbTestData['text'].apply(denoise_text)
imdbValidationData['text'] = imdbValidationData['text'].apply(denoise_text)

# Apply function on review column
imdbTrainData['text'] = imdbTrainData['text'].apply(remove_special_characters)
imdbTestData['text'] = imdbTestData['text'].apply(remove_special_characters)
imdbValidationData['text'] = imdbValidationData['text'].apply(remove_special_characters)

# # Apply function on review column
# imdbTrainData['text'] = imdbTrainData['text'].apply(simple_stemmer)
# imdbTestData['text'] = imdbTestData['text'].apply(simple_stemmer)
# imdbValidationData['text'] = imdbValidationData['text'].apply(simple_stemmer)

# set stopwords to english
stop = set(stopwords.words('english'))
print(stop)

# # Apply function on review column
# imdbTrainData['text'] = imdbTrainData['text'].apply(remove_stopwords)
# imdbTestData['text'] = imdbTestData['text'].apply(remove_stopwords)
# imdbValidationData['text'] = imdbValidationData['text'].apply(remove_stopwords)

# normalized train reviews
norm_train_reviews = imdbTrainData.text

# Normalized test reviewssirali
norm_test_reviews = imdbTestData.text

# Normalized test reviewssirali
norm_validation_reviews = imdbValidationData.text

# Bert Embedding
bert = BertEmbedding()
bert_word_train_features = norm_train_reviews.apply(Bert)
bert_word_test_features = norm_test_reviews.apply(Bert)
bert_word_validation_features = norm_validation_reviews.apply(Bert)


with open('../MyDrive/BertTrain.npy', 'wb') as f:
    np.save(f, np.array(bert_word_train_features))
print("save train")

with open('../MyDrive/BertTest.npy', 'wb') as f:
    np.save(f, np.array(bert_word_test_features))

print("save test")

with open('../MyDrive/BertValidation.npy', 'wb') as f:
    np.save(f, np.array(bert_word_validation_features))

print("save validation")

# with open('../MyDrive/BertTrain.npy', 'rb') as f:
#     bert_word_train_features = np.load(f)

# with open('../MyDrive/BertTest.npy', 'rb') as f:
#     bert_word_test_features = np.load(f)

# with open('../MyDrive/BertValidation.npy', 'rb') as f:
#     bert_word_validation_features = np.load(f)
# print("reaaad")

# sentiment data
train_sentiments = imdbTrainData['label']
test_sentiments = imdbTestData['label']
validation_sentiments = imdbValidationData['label']


#####################################################################SVM RBF##################################################################################
Gamma = [1e-3, 1e-4]
C = [0.01, 0.1, 1]
counter = 0
counterFlag = 0
prametersList = []
maxScore = 0
svm_bow_predict_on_test = []
svmLists = []
for cSVM in C:
    for gammaSVM in Gamma:

        prametersList.append("C is " + str(cSVM) + " and gamma is " + str(gammaSVM))
        svm = SVC(kernel='rbf', C=cSVM, gamma=gammaSVM)
        svm_bow = svm.fit(bert_word_train_features, train_sentiments)
        svmLists.append(svm)
        svm_bow_predict = svm.predict(bert_word_validation_features)
        svm_bow_score = accuracy_score(validation_sentiments, svm_bow_predict)
        print("done")
        if (svm_bow_score > maxScore):
            print("avaz shod")
            maxScore = svm_bow_score
            maxScoreC = cSVM
            maxScoreGamma = gammaSVM
            counterFlag = counter
        counter += 1

svm = svmLists[counterFlag]
svm_bow_predict = svm.predict(bert_word_test_features)

print(prametersList[counterFlag])

# Accuracy score for bag of words
svm_bow_score = accuracy_score(test_sentiments, svm_bow_predict)
print("svm_bow_score :", svm_bow_score)

# Classification report for bag of words
svm_bow_report = classification_report(test_sentiments, svm_bow_predict, target_names=['Positive', 'Negative'])
print(svm_bow_report)

# confusion matrix for bag of words
cm_bow = confusion_matrix(test_sentiments, svm_bow_predict, labels=[1, 0])
print(cm_bow)

# ROC
from sklearn import metrics

metrics.plot_roc_curve(svm, bert_word_test_features,
                       test_sentiments)
plt.show()

# AUC
fpr, tpr, thresholds = metrics.roc_curve(test_sentiments, svm_bow_predict)
print("AUC: " + str(metrics.auc(fpr, tpr)))

#################################################################################################################################################################
