import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import nltk
from nltk.corpus import stopwords
from bs4 import BeautifulSoup
import re
from nltk.tokenize.toktok import ToktokTokenizer
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.metrics import classification_report,confusion_matrix,accuracy_score
from gensim.models import word2vec


#Removing the html strips
def strip_html(text):
    soup = BeautifulSoup(text, "html.parser")
    return soup.get_text()

#Removing the square brackets
def remove_between_square_brackets(text):
    return re.sub('\[[^]]*\]', '', text)

#Removing the noisy text
def denoise_text(text):
    text = strip_html(text)
    text = remove_between_square_brackets(text)
    return text

#Define function for removing special characters
def remove_special_characters(text, remove_digits=True):
    pattern=r'[^a-zA-z0-9\s]'
    text=re.sub(pattern,'',text)
    return text

#Stemming the text
def simple_stemmer(text):
    ps=nltk.porter.PorterStemmer()
    text= ' '.join([ps.stem(word) for word in text.split()])
    return text

#removing the stopwords
def remove_stopwords(text, is_lower_case=False):
    tokens = tokenizer.tokenize(text)
    tokens = [token.strip() for token in tokens]
    if is_lower_case:
        filtered_tokens = [token for token in tokens if token not in stopword_list]
    else:
        filtered_tokens = [token for token in tokens if token.lower() not in stopword_list]
    filtered_text = ' '.join(filtered_tokens)
    return filtered_text


# This function splits a review into sentences
def review_sentences(review, tokenizer, remove_stopwords=False):
    # 1. Using nltk tokenizer
    raw_sentences = tokenizer.tokenize(review.strip())
    sentences = []
    # 2. Loop for each sentence
    for raw_sentence in raw_sentences:
        if len(raw_sentence)>0:
            sentences.append(review_wordlist(raw_sentence,\
                                            remove_stopwords))

    # This returns the list of lists
    return sentences


# Function to average all word vectors in a paragraph
def featureVecMethod(words, model, num_features):
    # Pre-initialising empty numpy array for speed
    featureVec = np.zeros(num_features, dtype="float32")
    nwords = 0

    # Converting Index2Word which is a list to a set for better speed in the execution.
    index2word_set = set(model.wv.index2word)

    for word in words:
        if word in index2word_set:
            nwords = nwords + 1
            featureVec = np.add(featureVec, model[word])

    # Dividing the result by number of words to get average
    featureVec = np.divide(featureVec, nwords)
    return featureVec


# Function for calculating the average feature vector
def getAvgFeatureVecs(reviews, model, num_features):
    counter = 0
    reviewFeatureVecs = np.zeros((len(reviews), num_features), dtype="float32")
    for review in reviews:
        # Printing a status message every 1000th review
        if counter % 1000 == 0:
            print("Review %d of %d" % (counter, len(reviews)))

        reviewFeatureVecs[counter] = featureVecMethod(review, model, num_features)
        counter = counter + 1

    return reviewFeatureVecs


# This function converts a text to a sequence of words.
def review_wordlist(review, remove_stopwords=False):
    # 1. Removing html tags
    review_text = BeautifulSoup(review).get_text()
    # 2. Removing non-letter.
    review_text = re.sub("[^a-zA-Z]", " ", review_text)
    # 3. Converting to lower case and splitting
    words = review_text.lower().split()
    # 4. Optionally remove stopwords
    if remove_stopwords:
        stops = set(stopwords.words("english"))
        words = [w for w in words if not w in stops]

    return (words)


import warnings
warnings.filterwarnings('ignore')

#Importing the training data
imdbTrainData = pd.read_csv('Train.csv')
imdbTestData = pd.read_csv('Test.csv')
imdbValidationData = pd.read_csv('Valid.csv')


#Printing some detailes from the training data
print(imdbTrainData.shape)
print(imdbTrainData.head(10))
print(imdbTrainData.describe())
print(imdbTrainData['label'].value_counts())


#Tokenization of text
tokenizer = ToktokTokenizer()

#Setting English stopwords
#nltk.download('stopwords')
stopword_list = nltk.corpus.stopwords.words('english') # This command needed ===> python3 -m nltk.downloader stopwords

#Apply function on review column
imdbTrainData['text'] = imdbTrainData['text'].apply(denoise_text)
imdbTestData['text'] = imdbTestData['text'].apply(denoise_text)
imdbValidationData['text'] = imdbValidationData['text'].apply(denoise_text)

#Apply function on review column
imdbTrainData['text'] = imdbTrainData['text'].apply(remove_special_characters)
imdbTestData['text'] = imdbTestData['text'].apply(remove_special_characters)
imdbValidationData['text'] = imdbValidationData['text'].apply(remove_special_characters)

#Apply function on review column
imdbTrainData['text'] = imdbTrainData['text'].apply(simple_stemmer)
imdbTestData['text'] = imdbTestData['text'].apply(simple_stemmer)
imdbValidationData['text'] = imdbValidationData['text'].apply(simple_stemmer)


#set stopwords to english
stop=set(stopwords.words('english'))
print(stop)

#Apply function on review column
imdbTrainData['text']=imdbTrainData['text'].apply(remove_stopwords)
imdbTestData['text']=imdbTestData['text'].apply(remove_stopwords)
imdbValidationData['text'] = imdbValidationData['text'].apply(remove_stopwords)

#normalized train reviews
norm_train_reviews = imdbTrainData.text

#Normalized test reviewssirali
norm_test_reviews = imdbTestData.text

#Normalized Validation reviews
norm_validation_reviews = imdbValidationData.text

# sentiment data
train_sentiments = imdbTrainData['label']
test_sentiments = imdbTestData['label']
validation_sentiments = imdbValidationData['label']


#############################################################Word2Vec#####################################3
sentences = []
print("Parsing sentences from training set")
for review in norm_train_reviews:
    sentences += review_sentences(review, tokenizer)

print("Training model....")
model = word2vec.Word2Vec(sentences,\
                          size=3000,\
                         )

# To make the model memory efficient
model.init_sims(replace=True)

# Calculating average feature vector for training set
clean_train_reviews = []
for review in norm_train_reviews:
    clean_train_reviews.append(review_wordlist(review, remove_stopwords=True))

trainDataVecs = getAvgFeatureVecs(clean_train_reviews, model, 3000)

print(trainDataVecs)

# Calculating average feature vactors for test set
clean_test_reviews = []
for review in norm_test_reviews:
    clean_test_reviews.append(review_wordlist(review, remove_stopwords=True))

testDataVecs = getAvgFeatureVecs(clean_test_reviews, model, 3000)


clean_validation_reviews = []
for review in norm_validation_reviews:
    clean_validation_reviews.append(review_wordlist(review, remove_stopwords=True))

validationDataVecs = getAvgFeatureVecs(clean_validation_reviews, model, 3000)
#####################################################################################################################################


#################################################################SVM Linear#####################################################################################
C = [0.001, 0.01, 0.1, 1]
counter = 0
counterFlag = 0
prametersList = []
maxScore = 0
svm_bow_predict_on_test = []
svmLists = []
for cSVM in C:

    prametersList.append("C is " + str(cSVM))
    svm = SVC(kernel='linear', C=cSVM)
    svm_bow = svm.fit(trainDataVecs, train_sentiments)
    svmLists.append(svm)
    svm_bow_predict = svm.predict(validationDataVecs)
    svm_bow_score = accuracy_score(validation_sentiments, svm_bow_predict)
    print("done")
    if (svm_bow_score > maxScore):
        print("avaz shod")
        maxScore = svm_bow_score
        maxScoreC = cSVM
        counterFlag = counter
    counter += 1

svm = svmLists[counterFlag]
svm_bow_predict = svm.predict(testDataVecs)

print(prametersList[counterFlag])

# Accuracy score for bag of words
svm_bow_score = accuracy_score(test_sentiments, svm_bow_predict)
print("svm_bow_score :", svm_bow_score)

# Classification report for bag of words
svm_bow_report = classification_report(test_sentiments, svm_bow_predict, target_names=['Positive', 'Negative'])
print(svm_bow_report)

# confusion matrix for bag of words
cm_bow = confusion_matrix(test_sentiments, svm_bow_predict, labels=[1, 0])
print(cm_bow)

# ROC
from sklearn import metrics

metrics.plot_roc_curve(svm, testDataVecs,
                       test_sentiments)
plt.show()

# AUC
fpr, tpr, thresholds = metrics.roc_curve(test_sentiments, svm_bow_predict)
print("AUC: " + str(metrics.auc(fpr, tpr)))
###############################################################################################################################################

